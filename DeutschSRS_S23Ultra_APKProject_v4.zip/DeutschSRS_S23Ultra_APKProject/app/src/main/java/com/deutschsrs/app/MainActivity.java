package com.deutschsrs.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private FrameLayout fullscreenContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private static final int REQ_SPEECH = 4201;
    private static final int REQ_PICK_VIDEO = 4202;
    private static final int REQ_PICK_SUBTITLE = 4204;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        FrameLayout root = new FrameLayout(this);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new AppChromeClient());
        web.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        web.addJavascriptInterface(new VideoBridge(), "AndroidVideo");
        web.addJavascriptInterface(new AudioExtractBridge(), "AndroidAudio");
        web.addJavascriptInterface(new TtsBridge(), "AndroidTts");
        web.addJavascriptInterface(new SubtitleBridge(), "AndroidSubtitle");
        web.addJavascriptInterface(new TranscribeBridge(), "AndroidTranscribe");
        web.addJavascriptInterface(new OrientationBridge(), "AndroidOrientation");
        web.loadUrl("file:///android_asset/index.html");

        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setVisibility(View.GONE);
        fullscreenContainer.setBackgroundColor(0xFF000000);

        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int r = tts.setLanguage(Locale.GERMANY);
                    ttsReady = (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED);
                }
            }
        });
    }

    // ---------- полноэкранное видео (fullscreen для <video>) ----------
    private class AppChromeClient extends WebChromeClient {
        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }
            customView = view;
            customViewCallback = callback;
            web.setVisibility(View.GONE);
            fullscreenContainer.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            fullscreenContainer.setVisibility(View.VISIBLE);
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            web.setVisibility(View.VISIBLE);
            fullscreenContainer.setVisibility(View.GONE);
            fullscreenContainer.removeView(customView);
            if (customViewCallback != null) customViewCallback.onCustomViewHidden();
            customView = null;
            customViewCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            ((AppChromeClient) web.getWebChromeClient()).onHideCustomView();
        } else {
            super.onBackPressed();
        }
    }

    // ---------- нативная озвучка немецкого текста (надёжнее, чем speechSynthesis в WebView) ----------
    private class TtsBridge {
        @JavascriptInterface
        public void speak(final String text) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (tts != null && ttsReady) {
                        tts.stop();
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utt1");
                    } else {
                        Toast.makeText(MainActivity.this,
                                "Немецкий голос не найден. Настройки → Общее управление → Языки и время → Синтез речи → добавить немецкий.",
                                Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (tts != null) tts.stop();
                }
            });
        }

        @JavascriptInterface
        public String getEngines() {
            JSONArray arr = new JSONArray();
            try {
                List<TextToSpeech.EngineInfo> engines =
                        (tts != null) ? tts.getEngines() : new ArrayList<TextToSpeech.EngineInfo>();
                for (TextToSpeech.EngineInfo e : engines) {
                    JSONObject o = new JSONObject();
                    o.put("name", e.name);
                    o.put("label", e.label);
                    arr.put(o);
                }
            } catch (Exception ex) {
                // отдаём пустой список, JS покажет "недоступно"
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void setEngine(final String enginePackage) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (tts != null) {
                        tts.stop();
                        tts.shutdown();
                    }
                    ttsReady = false;
                    tts = new TextToSpeech(MainActivity.this, new TextToSpeech.OnInitListener() {
                        @Override public void onInit(int status) {
                            if (status == TextToSpeech.SUCCESS) {
                                int r = tts.setLanguage(Locale.GERMANY);
                                ttsReady = (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED);
                            }
                            final boolean ok = ttsReady;
                            web.post(new Runnable() {
                                @Override public void run() {
                                    web.evaluateJavascript("window.onTtsEngineReady && window.onTtsEngineReady(" + ok + ");", null);
                                }
                            });
                        }
                    }, enginePackage);
                }
            });
        }

        @JavascriptInterface
        public String getVoices() {
            JSONArray arr = new JSONArray();
            try {
                if (tts != null && ttsReady) {
                    for (Voice v : tts.getVoices()) {
                        if (v.getLocale() != null && "de".equals(v.getLocale().getLanguage())) {
                            JSONObject o = new JSONObject();
                            o.put("name", v.getName());
                            o.put("quality", v.getQuality());
                            o.put("network", v.isNetworkConnectionRequired());
                            o.put("locale", v.getLocale().toString());
                            arr.put(o);
                        }
                    }
                }
            } catch (Exception ex) {
                // отдаём пустой список при любой ошибке
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void setVoice(final String voiceName) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (tts == null) return;
                    try {
                        for (Voice v : tts.getVoices()) {
                            if (v.getName().equals(voiceName)) {
                                tts.setVoice(v);
                                break;
                            }
                        }
                    } catch (Exception ex) {
                        Toast.makeText(MainActivity.this, "Не удалось выбрать голос: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    // ---------- голосовой ввод (кнопка микрофона в чате) ----------
    private class VoiceBridge {
        @JavascriptInterface
        public void startListening() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Sprich auf Deutsch…");
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(intent, REQ_SPEECH);
                    } else {
                        Toast.makeText(MainActivity.this, "Голосовой ввод недоступен на этом устройстве", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // ---------- выбор видеофайла (этап 1 функции субтитров) ----------
    private class VideoBridge {
        @JavascriptInterface
        public void pickVideo() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("video/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, REQ_PICK_VIDEO);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть выбор файлов: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // ---------- извлечение звуковой дорожки из видео (этап 2) ----------
    private class AudioExtractBridge {
        @JavascriptInterface
        public void extractAudio() {
            web.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript("window.onAudioExtractStart && window.onAudioExtractStart();", null);
                }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    MediaExtractor extractor = null;
                    MediaMuxer muxer = null;
                    try {
                        File videoFile = new File(getCacheDir(), "current_video.mp4");
                        if (!videoFile.exists()) {
                            throw new Exception("Видео не найдено — выберите видео заново");
                        }
                        File audioFile = new File(getCacheDir(), "current_audio.m4a");

                        extractor = new MediaExtractor();
                        extractor.setDataSource(videoFile.getAbsolutePath());

                        int audioTrackIndex = -1;
                        MediaFormat audioFormat = null;
                        int trackCount = extractor.getTrackCount();
                        for (int i = 0; i < trackCount; i++) {
                            MediaFormat format = extractor.getTrackFormat(i);
                            String mime = format.getString(MediaFormat.KEY_MIME);
                            if (mime != null && mime.startsWith("audio/")) {
                                audioTrackIndex = i;
                                audioFormat = format;
                                break;
                            }
                        }
                        if (audioTrackIndex == -1) {
                            throw new Exception("В этом видео не найдена звуковая дорожка");
                        }
                        extractor.selectTrack(audioTrackIndex);

                        muxer = new MediaMuxer(audioFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                        int outTrackIndex = muxer.addTrack(audioFormat);
                        muxer.start();

                        ByteBuffer buffer = ByteBuffer.allocate(1 << 20);
                        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
                        long totalDurationUs = audioFormat.containsKey(MediaFormat.KEY_DURATION)
                                ? audioFormat.getLong(MediaFormat.KEY_DURATION) : 0;
                        int lastPercentSent = -1;

                        while (true) {
                            int sampleSize = extractor.readSampleData(buffer, 0);
                            if (sampleSize < 0) break;
                            bufferInfo.offset = 0;
                            bufferInfo.size = sampleSize;
                            bufferInfo.presentationTimeUs = extractor.getSampleTime();
                            bufferInfo.flags = extractor.getSampleFlags();
                            muxer.writeSampleData(outTrackIndex, buffer, bufferInfo);

                            if (totalDurationUs > 0) {
                                final int percent = (int) Math.min(100, (bufferInfo.presentationTimeUs * 100) / totalDurationUs);
                                if (percent != lastPercentSent) {
                                    lastPercentSent = percent;
                                    web.post(new Runnable() {
                                        @Override public void run() {
                                            web.evaluateJavascript("window.onAudioExtractProgress && window.onAudioExtractProgress(" + percent + ");", null);
                                        }
                                    });
                                }
                            }
                            extractor.advance();
                        }

                        muxer.stop();
                        muxer.release();
                        muxer = null;
                        extractor.release();
                        extractor = null;

                        final long audioSizeBytes = audioFile.length();
                        final double durationSec = totalDurationUs > 0 ? totalDurationUs / 1_000_000.0 : 0;
                        final String escapedPath = JSONObject.quote("file://" + audioFile.getAbsolutePath());
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onAudioExtracted && window.onAudioExtracted(" + escapedPath + ", " + audioSizeBytes + ", " + durationSec + ");", null);
                            }
                        });
                    } catch (Exception e) {
                        try { if (muxer != null) muxer.release(); } catch (Exception ignore) { }
                        try { if (extractor != null) extractor.release(); } catch (Exception ignore) { }
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onAudioExtractError && window.onAudioExtractError(" + escapedErr + ");", null);
                            }
                        });
                    }
                }
            }).start();
        }
    }

    // ---------- выбор файла субтитров .srt/.vtt (этап 3, вариант «готовый файл») ----------
    private class SubtitleBridge {
        @JavascriptInterface
        public void pickSubtitle() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, REQ_PICK_SUBTITLE);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть выбор файлов: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // ---------- отправка извлечённого звука в Gemini через Cloudflare Worker (этап 3, вариант «распознать через ИИ») ----------
    private class TranscribeBridge {
        @JavascriptInterface
        public void transcribe(final String workerUrl, final String secret) {
            web.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript("window.onTranscribeStart && window.onTranscribeStart();", null);
                }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    HttpURLConnection conn = null;
                    try {
                        File audioFile = new File(getCacheDir(), "current_audio.m4a");
                        if (!audioFile.exists()) {
                            throw new Exception("Сначала извлеки звук из видео на предыдущем шаге");
                        }

                        byte[] raw = new byte[(int) audioFile.length()];
                        FileInputStream fis = new FileInputStream(audioFile);
                        int off = 0, n;
                        while (off < raw.length && (n = fis.read(raw, off, raw.length - off)) != -1) {
                            off += n;
                        }
                        fis.close();
                        String audioB64 = android.util.Base64.encodeToString(raw, android.util.Base64.NO_WRAP);

                        JSONObject payload = new JSONObject();
                        payload.put("mode", "transcribeSubtitles");
                        payload.put("mimeType", "audio/mp4");
                        payload.put("audioBase64", audioB64);

                        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);

                        URL url = new URL(workerUrl);
                        conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("POST");
                        conn.setDoOutput(true);
                        conn.setConnectTimeout(30000);
                        conn.setReadTimeout(180000);
                        conn.setRequestProperty("Content-Type", "application/json");
                        conn.setRequestProperty("X-App-Secret", secret == null ? "" : secret);
                        conn.setFixedLengthStreamingMode(body.length);

                        OutputStream os = conn.getOutputStream();
                        os.write(body);
                        os.flush();
                        os.close();

                        int code = conn.getResponseCode();
                        InputStream respStream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] buf = new byte[1 << 16];
                        int rn;
                        while (respStream != null && (rn = respStream.read(buf)) != -1) {
                            bos.write(buf, 0, rn);
                        }
                        if (respStream != null) respStream.close();
                        String respText = new String(bos.toByteArray(), StandardCharsets.UTF_8);

                        if (code < 200 || code >= 300) {
                            throw new Exception("HTTP " + code + ": " + respText);
                        }

                        final String escaped = JSONObject.quote(respText);
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onTranscribeResult && window.onTranscribeResult(" + escaped + ");", null);
                            }
                        });
                    } catch (Exception e) {
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onTranscribeError && window.onTranscribeError(" + escapedErr + ");", null);
                            }
                        });
                    } finally {
                        if (conn != null) conn.disconnect();
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void transcribeChunk(final String workerUrl, final String secret, final double startSec, final double endSec, final int chunkIndex, final int totalChunks) {
            web.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript("window.onTranscribeChunkStart && window.onTranscribeChunkStart(" + chunkIndex + ", " + totalChunks + ");", null);
                }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    HttpURLConnection conn = null;
                    MediaExtractor extractor = null;
                    MediaMuxer muxer = null;
                    File chunkFile = null;
                    try {
                        File audioFile = new File(getCacheDir(), "current_audio.m4a");
                        if (!audioFile.exists()) {
                            throw new Exception("Сначала извлеки звук из видео на предыдущем шаге");
                        }
                        chunkFile = new File(getCacheDir(), "chunk_" + chunkIndex + ".m4a");

                        extractor = new MediaExtractor();
                        extractor.setDataSource(audioFile.getAbsolutePath());
                        if (extractor.getTrackCount() == 0) {
                            throw new Exception("В извлечённом звуке нет дорожек");
                        }
                        MediaFormat format = extractor.getTrackFormat(0);
                        extractor.selectTrack(0);

                        long startUs = (long) (startSec * 1_000_000L);
                        long endUs = (long) (endSec * 1_000_000L);
                        extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

                        muxer = new MediaMuxer(chunkFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                        int outTrack = muxer.addTrack(format);
                        muxer.start();

                        ByteBuffer buffer = ByteBuffer.allocate(1 << 20);
                        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                        long basePts = -1;

                        while (true) {
                            long sampleTime = extractor.getSampleTime();
                            if (sampleTime < 0 || sampleTime > endUs) break;
                            int sampleSize = extractor.readSampleData(buffer, 0);
                            if (sampleSize < 0) break;
                            if (basePts < 0) basePts = sampleTime;
                            info.offset = 0;
                            info.size = sampleSize;
                            info.presentationTimeUs = Math.max(0, sampleTime - basePts);
                            info.flags = extractor.getSampleFlags();
                            muxer.writeSampleData(outTrack, buffer, info);
                            if (!extractor.advance()) break;
                        }

                        muxer.stop();
                        muxer.release();
                        muxer = null;
                        extractor.release();
                        extractor = null;

                        if (!chunkFile.exists() || chunkFile.length() < 200) {
                            throw new Exception("Пустой фрагмент — похоже, звук уже закончился раньше этой части");
                        }

                        byte[] raw = new byte[(int) chunkFile.length()];
                        FileInputStream fis = new FileInputStream(chunkFile);
                        int off = 0, n;
                        while (off < raw.length && (n = fis.read(raw, off, raw.length - off)) != -1) {
                            off += n;
                        }
                        fis.close();
                        String audioB64 = android.util.Base64.encodeToString(raw, android.util.Base64.NO_WRAP);

                        JSONObject payload = new JSONObject();
                        payload.put("mode", "transcribeSubtitles");
                        payload.put("mimeType", "audio/mp4");
                        payload.put("audioBase64", audioB64);
                        byte[] bodyBytes = payload.toString().getBytes(StandardCharsets.UTF_8);

                        URL url = new URL(workerUrl);
                        conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("POST");
                        conn.setDoOutput(true);
                        conn.setConnectTimeout(30000);
                        conn.setReadTimeout(180000);
                        conn.setRequestProperty("Content-Type", "application/json");
                        conn.setRequestProperty("X-App-Secret", secret == null ? "" : secret);
                        conn.setFixedLengthStreamingMode(bodyBytes.length);
                        OutputStream os = conn.getOutputStream();
                        os.write(bodyBytes);
                        os.flush();
                        os.close();

                        int code = conn.getResponseCode();
                        InputStream respStream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] buf = new byte[1 << 16];
                        int rn;
                        while (respStream != null && (rn = respStream.read(buf)) != -1) {
                            bos.write(buf, 0, rn);
                        }
                        if (respStream != null) respStream.close();
                        String respText = new String(bos.toByteArray(), StandardCharsets.UTF_8);

                        if (code < 200 || code >= 300) {
                            throw new Exception("HTTP " + code + ": " + respText);
                        }

                        final String escaped = JSONObject.quote(respText);
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onTranscribeChunkResult && window.onTranscribeChunkResult(" + chunkIndex + ", " + totalChunks + ", " + startSec + ", " + escaped + ");", null);
                            }
                        });
                    } catch (Exception e) {
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onTranscribeChunkError && window.onTranscribeChunkError(" + chunkIndex + ", " + totalChunks + ", " + escapedErr + ");", null);
                            }
                        });
                    } finally {
                        try { if (muxer != null) muxer.release(); } catch (Exception ignore) { }
                        try { if (extractor != null) extractor.release(); } catch (Exception ignore) { }
                        if (conn != null) conn.disconnect();
                        if (chunkFile != null) chunkFile.delete();
                    }
                }
            }).start();
        }
    }

    // ---------- блокировка ориентации для «театрального» просмотра видео с субтитрами ----------
    private class OrientationBridge {
        @JavascriptInterface
        public void lockLandscape() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                }
            });
        }
        @JavascriptInterface
        public void unlock() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                final String escaped = JSONObject.quote(results.get(0));
                web.post(new Runnable() {
                    @Override public void run() {
                        web.evaluateJavascript("window.onSpeechResult && window.onSpeechResult(" + escaped + ");", null);
                    }
                });
            }
            return;
        }

        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData();
            if (uri == null) return;
            web.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript("window.onVideoImportStart && window.onVideoImportStart();", null);
                }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        File outFile = new File(getCacheDir(), "current_video.mp4");
                        ContentResolver cr = getContentResolver();
                        InputStream in = cr.openInputStream(uri);
                        OutputStream out = new FileOutputStream(outFile);
                        byte[] buf = new byte[1 << 16];
                        int n;
                        while ((n = in.read(buf)) != -1) {
                            out.write(buf, 0, n);
                        }
                        in.close();
                        out.close();
                        final String escapedPath = JSONObject.quote("file://" + outFile.getAbsolutePath());
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onVideoImported && window.onVideoImported(" + escapedPath + ");", null);
                            }
                        });
                    } catch (Exception e) {
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onVideoImportError && window.onVideoImportError(" + escapedErr + ");", null);
                            }
                        });
                    }
                }
            }).start();
        }

        if (requestCode == REQ_PICK_SUBTITLE && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData();
            if (uri == null) return;
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        ContentResolver cr = getContentResolver();
                        InputStream in = cr.openInputStream(uri);
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] buf = new byte[1 << 16];
                        int n;
                        while (in != null && (n = in.read(buf)) != -1) {
                            bos.write(buf, 0, n);
                        }
                        if (in != null) in.close();
                        String text = new String(bos.toByteArray(), StandardCharsets.UTF_8);
                        if (text.length() > 0 && text.charAt(0) == '\uFEFF') {
                            text = text.substring(1);
                        }
                        final String escaped = JSONObject.quote(text);
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onSubtitleImported && window.onSubtitleImported(" + escaped + ");", null);
                            }
                        });
                    } catch (Exception e) {
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onSubtitleImportError && window.onSubtitleImportError(" + escapedErr + ");", null);
                            }
                        });
                    }
                }
            }).start();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
